public class NoOilPanException extends Exception {
    public String toString(){
        return "There is no oil pan in the car";
    }
}
